// ============================================================
// CENTRAL CONTENT FILE — Eucharist & Mary
// All text, node data, and language options live here.
// Add translations, images, and new nodes from this file only.
// ============================================================

export const LANGUAGES = [
  { code: 'it', label: 'Italiano' },
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Español' },
  { code: 'pt', label: 'Portugues' },
  { code: 'fr', label: 'Français' },
  { code: 'de', label: 'Deutsch' },
  { code: 'ru', label: 'Русские' },
  { code: 'el', label: 'Ελληνικα' },
  { code: 'hu', label: 'Magyar' },
  { code: 'nl', label: 'Nederlandse' },
  { code: 'pl', label: 'Polski' },
  { code: 'vi', label: 'Tiếng việt' },
  { code: 'fil', label: 'Filipino' },
  { code: 'zh', label: '中国語' },
  { code: 'ja', label: '日本語' },
  { code: 'ar', label: 'العربية', rtl: true },
  { code: 'ur', label: 'اردو', rtl: true },
  { code: 'si', label: 'Sri Lanka' },
  { code: 'other', label: 'Other languages' },
];

export const CONTENT = {
  eucharist: {
    main: {
      id: 'eucharist-main',
      label: 'The Holy\nEucharist',
      subtitle: 'The Source and Summit of Christian Life',
      symbol: '✝',
    },
    children: [
      {
        id: 'eucharist-scripture',
        label: 'Scripture',
        subtitle: 'The Word of God on the Eucharist',
        isScripture: true,
        image: null, // future: '/images/eucharist-scripture.jpg'
        content: [
          {
            heading: 'The Bread of Life Discourse',
            body: `[Placeholder — verified theological content will be added here.]\n\nJesus speaks plainly in the synagogue at Capernaum: "I am the living bread which came down from heaven; if any one eats of this bread, he will live for ever; and the bread which I shall give for the life of the world is my flesh." (John 6:51, RSV-2CE)\n\nWhen many disciples found this teaching hard and left, Jesus did not retract His words. He turned to the Twelve: "Will you also go away?" (John 6:67).`,
          },
          {
            heading: 'The Institution of the Eucharist',
            body: `[Placeholder — verified theological content will be added here.]\n\n"Now as they were eating, Jesus took bread, and blessed, and broke it, and gave it to the disciples and said, 'Take, eat; this is my body.' And he took a cup, and when he had given thanks he gave it to them, saying, 'Drink of it, all of you; for this is my blood of the covenant, which is poured out for many for the forgiveness of sins.'" (Matthew 26:26–28, RSV-2CE)`,
          },
          {
            heading: 'The Pauline Witness',
            body: `[Placeholder — verified theological content will be added here.]\n\n"For I received from the Lord what I also delivered to you, that the Lord Jesus on the night when he was betrayed took bread, and when he had given thanks, he broke it, and said, 'This is my body which is for you. Do this in remembrance of me.'" (1 Corinthians 11:23–24, RSV-2CE)`,
          },
        ],
      },
      {
        id: 'eucharist-fathers',
        label: 'Early Church\nFathers',
        subtitle: 'Witnesses of the Ancient Faith',
        isScripture: false,
        image: null,
        content: [
          {
            heading: 'St. Ignatius of Antioch (c. 107 AD)',
            body: `[Placeholder — verified theological content will be added here.]\n\nWriting to the Smyrnaeans, St. Ignatius warns against those who "abstain from the Eucharist and from prayer, because they do not confess that the Eucharist is the flesh of our Saviour Jesus Christ." This is among the earliest post-apostolic witnesses to the Real Presence.`,
          },
          {
            heading: 'St. Justin Martyr (c. 150 AD)',
            body: `[Placeholder — verified theological content will be added here.]\n\nIn his First Apology, Justin describes the Eucharist to the Roman Emperor: "For not as common bread and common drink do we receive these… the food which has been made into the Eucharist by the Eucharistic prayer set down by Him… is both the flesh and the blood of that incarnated Jesus."`,
          },
          {
            heading: 'St. Cyril of Jerusalem (c. 350 AD)',
            body: `[Placeholder — verified theological content will be added here.]\n\nIn his Mystagogical Catecheses, Cyril instructs the newly baptized: "Since then He Himself declared and said of the Bread, 'This is My Body,' who shall dare to doubt any longer? And since He has Himself affirmed and said, 'This is My Blood,' who shall ever hesitate, saying, that it is not His blood?"`,
          },
        ],
      },
      {
        id: 'eucharist-teaching',
        label: 'Church\nTeaching',
        subtitle: 'The Magisterium Speaks',
        isScripture: false,
        image: null,
        content: [
          {
            heading: 'The Council of Trent (1551)',
            body: `[Placeholder — verified theological content will be added here.]\n\nThe Council of Trent dogmatically defined the doctrine of Transubstantiation: by the consecration of the bread and wine, the whole substance of the bread is converted into the Body of Christ and the whole substance of the wine into His Blood. Only the appearances of bread and wine remain.`,
          },
          {
            heading: 'Catechism of the Catholic Church (§ 1373–1381)',
            body: `[Placeholder — verified theological content will be added here.]\n\n"The mode of Christ's presence under the Eucharistic species is unique. It raises the Eucharist above all the sacraments as 'the perfection of the spiritual life and the end to which all the sacraments tend.' In the most blessed sacrament of the Eucharist 'the body and blood, together with the soul and divinity, of our Lord Jesus Christ…'" (CCC 1374)`,
          },
          {
            heading: 'Ecclesia de Eucharistia — St. John Paul II (2003)',
            body: `[Placeholder — verified theological content will be added here.]\n\nSt. John Paul II's final encyclical on the Eucharist affirmed: "The Church draws her life from the Eucharist. This truth does not simply express a daily experience of faith, but recapitulates the heart of the mystery of the Church."`,
          },
        ],
      },
      {
        id: 'eucharist-miracles',
        label: 'Eucharistic\nMiracles',
        subtitle: "Heaven's Confirmation",
        isScripture: false,
        image: null,
        content: [
          {
            heading: 'The Miracle of Lanciano (8th Century, Italy)',
            body: `[Placeholder — verified theological content will be added here.]\n\nA Basilian monk doubted the Real Presence during Mass. At the moment of consecration, the host visibly transformed into flesh and the wine into blood. Scientific analysis in 1970–1971 confirmed the flesh is human cardiac tissue, type AB blood — the same type found in the Shroud of Turin.`,
          },
          {
            heading: 'Buenos Aires (1992–1996, Argentina)',
            body: `[Placeholder — verified theological content will be added here.]\n\nA discarded host placed in water began to transform into a bloody substance. Analysis at Columbia University confirmed it was human cardiac muscle in an inflamed state — a suffering heart. Then-Cardinal Jorge Mario Bergoglio (later Pope Francis) oversaw its investigation.`,
          },
          {
            heading: 'Sokolka (2008, Poland)',
            body: `[Placeholder — verified theological content will be added here.]\n\nA consecrated host fell and was placed in water to dissolve. It transformed into a reddish tissue. Histological examination confirmed it was myocardial (heart muscle) tissue showing signs of agony — structurally integrated with the remaining bread.`,
          },
          {
            heading: "St. Carlo Acutis's Catalogue",
            body: `[Placeholder — verified theological content will be added here.]\n\nSt. Carlo Acutis dedicated himself to cataloguing Eucharistic miracles worldwide using his computer skills. He said: "The Eucharist is my highway to heaven." His travelling exhibition on Eucharistic miracles continues to circulate globally, bringing millions to deeper faith.`,
          },
        ],
      },
    ],
  },

  mary: {
    main: {
      id: 'mary-main',
      label: 'The Virgin\nMary',
      subtitle: 'Mother of God, Mother of the Church',
      symbol: '✦',
    },
    children: [
      {
        id: 'mary-scripture',
        label: 'Scripture',
        subtitle: 'Mary in the Word of God',
        isScripture: true,
        image: null,
        content: [
          {
            heading: 'The Annunciation',
            body: `[Placeholder — verified theological content will be added here.]\n\n"And he came to her and said, 'Hail, full of grace, the Lord is with you!' But she was greatly troubled at the saying, and considered in her mind what sort of greeting this might be." (Luke 1:28, RSV-2CE)\n\nThe Greek word kecharitomene — "full of grace" — is a unique, perfect passive participle indicating a completed and permanent state of grace.`,
          },
          {
            heading: 'The Magnificat',
            body: `[Placeholder — verified theological content will be added here.]\n\n"My soul magnifies the Lord, and my spirit rejoices in God my Savior, for he has regarded the low estate of his handmaiden. For behold, henceforth all generations will call me blessed; for he who is mighty has done great things for me, and holy is his name." (Luke 1:46–49, RSV-2CE)`,
          },
          {
            heading: 'At Cana and at Calvary',
            body: `[Placeholder — verified theological content will be added here.]\n\nAt the Wedding at Cana, Mary's intercession moves Christ to perform His first sign: "Do whatever he tells you." (John 2:5). At Calvary, Christ gives Mary to the beloved disciple — and through him, to all the faithful: "Behold, your mother!" (John 19:27, RSV-2CE).`,
          },
        ],
      },
      {
        id: 'mary-apparitions',
        label: 'Apparitions &\nMiracles',
        subtitle: "Our Lady's Visits to Her Children",
        isScripture: false,
        image: null,
        content: [
          {
            heading: 'Our Lady of Guadalupe (1531, Mexico)',
            body: `[Placeholder — verified theological content will be added here.]\n\nOur Lady appeared to St. Juan Diego, leaving her image on his tilma (cloak). The image has defied scientific explanation for nearly 500 years: there is no brushwork, the pigments are unknown, the eyes contain reflections consistent with a human eye, and the tilma fabric has never decayed. Nine million conversions followed within a decade.`,
          },
          {
            heading: 'Our Lady of Lourdes (1858, France)',
            body: `[Placeholder — verified theological content will be added here.]\n\nOur Lady appeared 18 times to St. Bernadette Soubirous in the grotto of Massabielle, identifying herself: "I am the Immaculate Conception." The spring waters of Lourdes have been associated with over 70 medically verified miraculous healings recognized by the Church.`,
          },
          {
            heading: 'Our Lady of Fatima (1917, Portugal)',
            body: `[Placeholder — verified theological content will be added here.]\n\nOur Lady appeared to three shepherd children — Lucia, Francisco, and Jacinta — six times. She entrusted the Three Secrets of Fatima, requested the Rosary daily, and called for consecration of Russia. The Miracle of the Sun on October 13, 1917, was witnessed by approximately 70,000 people.`,
          },
        ],
      },
      {
        id: 'mary-teaching',
        label: 'Church\nTeaching',
        subtitle: 'The Dogmas and Doctrines of Mary',
        isScripture: false,
        image: null,
        content: [
          {
            heading: 'Theotokos — Council of Ephesus (431 AD)',
            body: `[Placeholder — verified theological content will be added here.]\n\nThe Council of Ephesus solemnly defined Mary as Theotokos — God-bearer, or Mother of God. This title is not primarily about Mary but about Christ: it affirms that the one born of Mary is truly and fully God. Crowds celebrated in the streets of Ephesus for days.`,
          },
          {
            heading: 'The Immaculate Conception (1854)',
            body: `[Placeholder — verified theological content will be added here.]\n\nPope Pius IX defined ex cathedra: "The most Blessed Virgin Mary was, from the first moment of her conception, by a singular grace and privilege of almighty God and by virtue of the merits of Jesus Christ, Savior of the human race, preserved immune from all stain of original sin." (Ineffabilis Deus)`,
          },
          {
            heading: 'The Assumption (1950)',
            body: `[Placeholder — verified theological content will be added here.]\n\nPope Pius XII defined: "The Immaculate Mother of God, the ever Virgin Mary, having completed the course of her earthly life, was assumed body and soul into heavenly glory." (Munificentissimus Deus) — the most recent ex cathedra definition in Church history.`,
          },
        ],
      },
      {
        id: 'mary-tradition',
        label: 'Early Church &\nTradition',
        subtitle: 'Mary in the Ancient Church',
        isScripture: false,
        image: null,
        content: [
          {
            heading: 'Sub Tuum Praesidium (c. 250 AD)',
            body: `[Placeholder — verified theological content will be added here.]\n\nThe oldest known Marian prayer, discovered on a papyrus in Egypt: "Beneath your compassion we take refuge, O Mother of God; do not despise our petitions in time of trouble, but rescue us from dangers, only pure, only blessed one." This prayer predates the Council of Nicaea and witnesses to early Marian devotion.`,
          },
          {
            heading: 'The New Eve — St. Irenaeus (c. 180 AD)',
            body: `[Placeholder — verified theological content will be added here.]\n\nSt. Irenaeus of Lyon developed the parallel between Eve and Mary: "As Eve became by her disobedience the cause of death for herself and all mankind, so Mary, by her obedience, became the cause of salvation for herself and all mankind." This typology is foundational to Marian theology.`,
          },
          {
            heading: 'Mary Ever-Virgin — Ancient Tradition',
            body: `[Placeholder — verified theological content will be added here.]\n\nFrom the earliest centuries, Christians affirmed the perpetual virginity of Mary — before, during, and after the birth of Christ. This is witnessed in the writings of St. Athanasius, St. Epiphanius, St. Jerome, St. Ambrose, and St. Augustine, and is defined as a dogma of the Church.`,
          },
        ],
      },
    ],
  },
};
