import React from 'react';
import { LANGUAGES } from '../data/content.js';

export default function LanguageSelector({ open, language, onSelect }) {
  const s = {
    tray: {
      overflow: 'hidden',
      maxHeight: open ? '160px' : '0',
      transition: 'max-height 0.35s cubic-bezier(0.4,0,0.2,1)',
      background: 'var(--bg-header)',
      borderBottom: open ? '1px solid rgba(184,137,42,0.2)' : 'none',
    },
    inner: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px',
      padding: '14px 24px 16px',
    },
    chip: (active) => ({
      padding: '5px 14px',
      borderRadius: 'var(--radius-full)',
      border: '1px solid',
      borderColor: active ? 'var(--gold-light)' : 'rgba(212,175,90,0.25)',
      background: active ? 'var(--gold-light)' : 'rgba(212,175,90,0.06)',
      color: active ? 'var(--bg-header)' : 'rgba(212,175,90,0.8)',
      fontSize: '0.75rem',
      fontFamily: 'var(--font-sans)',
      cursor: 'pointer',
      transition: 'var(--transition)',
      fontWeight: active ? 600 : 400,
      whiteSpace: 'nowrap',
    }),
  };

  return (
    <div style={s.tray}>
      <div style={s.inner}>
        {LANGUAGES.map(lang => (
          <button
            key={lang.code}
            style={s.chip(language === lang.code)}
            onClick={() => onSelect(lang.code)}
            dir={lang.rtl ? 'rtl' : 'ltr'}
          >
            {lang.label}
          </button>
        ))}
      </div>
    </div>
  );
}
