import React from 'react';

export default function HintBar() {
  return (
    <div style={{
      background: 'var(--bg-header)',
      borderBottom: '1px solid rgba(184,137,42,0.12)',
      padding: '6px 24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '20px',
      flexShrink: 0,
    }}>
      <span style={{
        fontSize: '0.68rem',
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        color: 'rgba(212,175,90,0.55)',
        animation: 'hintPulse 3s ease-in-out infinite',
        userSelect: 'none',
      }}>
        ✦ Click the circle to expand · Click a node to read · Scroll to zoom · Drag to pan ✦
      </span>
    </div>
  );
}
