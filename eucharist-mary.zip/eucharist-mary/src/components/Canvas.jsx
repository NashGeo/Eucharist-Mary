import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { CONTENT } from '../data/content.js';

// ── Node size constants ─────────────────────────────────────
const MAIN_R   = 80;   // main node radius
const CHILD_R  = 58;   // child node radius
const ORBIT_R  = 220;  // orbit radius (center to center)

// ── Generate random but well-distributed child positions ────
function generatePositions(count = 4) {
  const sector = 360 / count;
  return Array.from({ length: count }, (_, i) => {
    const base  = i * sector;
    const angle = (base + sector * 0.15 + Math.random() * sector * 0.7) * (Math.PI / 180);
    const r     = ORBIT_R + (Math.random() - 0.5) * 55;
    return { x: Math.cos(angle) * r, y: Math.sin(angle) * r };
  });
}

// ── Curved SVG path from origin to child ───────────────────
function curvePath(cx, cy, tx, ty) {
  // Control point: mid-point nudged perpendicular to direction
  const mx  = (cx + tx) / 2;
  const my  = (cy + ty) / 2;
  const len = Math.sqrt((tx - cx) ** 2 + (ty - cy) ** 2) || 1;
  const px  = -(ty - cy) / len;
  const py  =  (tx - cx) / len;
  const bend = 28;
  return `M ${cx} ${cy} Q ${mx + px * bend} ${my + py * bend} ${tx} ${ty}`;
}

// ── Control bar icons ────────────────────────────────────────
const PanIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M12 12v.01" />
  </svg>
);
const ZoomInIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    <line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/>
  </svg>
);
const ZoomOutIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    <line x1="8" y1="11" x2="14" y2="11"/>
  </svg>
);
const ResetIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>
  </svg>
);

export default function Canvas({ activeTab, onNodeSelect, panelOpen }) {
  const containerRef = useRef(null);
  const [transform, setTransform]       = useState({ x: 0, y: 0, scale: 1 });
  const [panMode, setPanMode]           = useState(false);
  const [expanded, setExpanded]         = useState(false);
  const [childPositions, setChildPositions] = useState([]);
  const [activeChild, setActiveChild]   = useState(null);

  // Drag tracking
  const drag = useRef({ active: false, startX: 0, startY: 0, tx: 0, ty: 0, moved: false });

  const tabData = CONTENT[activeTab];

  // Re-collapse when tab changes
  useEffect(() => {
    setExpanded(false);
    setChildPositions([]);
    setActiveChild(null);
  }, [activeTab]);

  // Centre transform on mount/resize
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const { width, height } = el.getBoundingClientRect();
    setTransform({ x: width / 2, y: height / 2, scale: 1 });
  }, []);

  // ── Zoom ────────────────────────────────────────────────────
  const handleWheel = useCallback((e) => {
    e.preventDefault();
    const rect   = containerRef.current.getBoundingClientRect();
    const mx     = e.clientX - rect.left;
    const my     = e.clientY - rect.top;
    const factor = e.deltaY < 0 ? 1.1 : 0.91;
    setTransform(prev => {
      const newScale = Math.min(Math.max(prev.scale * factor, 0.25), 4);
      return {
        scale: newScale,
        x: mx - (mx - prev.x) * (newScale / prev.scale),
        y: my - (my - prev.y) * (newScale / prev.scale),
      };
    });
  }, []);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => el.removeEventListener('wheel', handleWheel);
  }, [handleWheel]);

  // ── Pan ──────────────────────────────────────────────────────
  const onMouseDown = useCallback((e) => {
    if (e.button !== 0) return;
    drag.current = { active: true, startX: e.clientX, startY: e.clientY, tx: transform.x, ty: transform.y, moved: false };
  }, [transform]);

  const onMouseMove = useCallback((e) => {
    if (!drag.current.active) return;
    const dx = e.clientX - drag.current.startX;
    const dy = e.clientY - drag.current.startY;
    if (Math.sqrt(dx * dx + dy * dy) > 4) drag.current.moved = true;
    if (drag.current.moved) {
      setTransform(prev => ({ ...prev, x: drag.current.tx + dx, y: drag.current.ty + dy }));
    }
  }, []);

  const onMouseUp = useCallback(() => { drag.current.active = false; }, []);

  // Touch pan
  const touch = useRef({ active: false, x: 0, y: 0, tx: 0, ty: 0 });
  const onTouchStart = useCallback((e) => {
    if (e.touches.length !== 1) return;
    touch.current = { active: true, x: e.touches[0].clientX, y: e.touches[0].clientY, tx: transform.x, ty: transform.y };
  }, [transform]);
  const onTouchMove = useCallback((e) => {
    if (!touch.current.active || e.touches.length !== 1) return;
    e.preventDefault();
    const dx = e.touches[0].clientX - touch.current.x;
    const dy = e.touches[0].clientY - touch.current.y;
    setTransform(prev => ({ ...prev, x: touch.current.tx + dx, y: touch.current.ty + dy }));
  }, []);
  const onTouchEnd = useCallback(() => { touch.current.active = false; }, []);

  // ── Zoom controls ────────────────────────────────────────────
  const zoomBy = useCallback((factor) => {
    const el = containerRef.current;
    if (!el) return;
    const { width, height } = el.getBoundingClientRect();
    const cx = width / 2, cy = height / 2;
    setTransform(prev => {
      const newScale = Math.min(Math.max(prev.scale * factor, 0.25), 4);
      return { scale: newScale, x: cx - (cx - prev.x) * (newScale / prev.scale), y: cy - (cy - prev.y) * (newScale / prev.scale) };
    });
  }, []);

  const resetView = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    const { width, height } = el.getBoundingClientRect();
    setTransform({ x: width / 2, y: height / 2, scale: 1 });
  }, []);

  // ── Node interactions ────────────────────────────────────────
  const handleMainClick = useCallback((e) => {
    e.stopPropagation();
    if (drag.current.moved) return;
    if (!expanded) {
      setChildPositions(generatePositions(tabData.children.length));
    }
    setExpanded(o => !o);
    setActiveChild(null);
  }, [expanded, tabData.children.length]);

  const handleChildClick = useCallback((e, child) => {
    e.stopPropagation();
    if (drag.current.moved) return;
    setActiveChild(child.id);
    onNodeSelect(child);
  }, [onNodeSelect]);

  // ── Styles ────────────────────────────────────────────────────
  const s = useMemo(() => ({
    container: {
      position: 'absolute', inset: 0,
      overflow: 'hidden',
      cursor: panMode ? 'grab' : 'default',
      // Canvas dot-grid background
      backgroundImage: `radial-gradient(circle, var(--canvas-dot) 1px, transparent 1px)`,
      backgroundSize: '28px 28px',
      background: 'var(--bg-canvas)',
    },
    world: {
      position: 'absolute',
      top: 0, left: 0,
      transformOrigin: '0 0',
      transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.scale})`,
      willChange: 'transform',
    },
    mainNode: (active) => ({
      position: 'absolute',
      width:  MAIN_R * 2,
      height: MAIN_R * 2,
      borderRadius: '50%',
      left: -MAIN_R,
      top:  -MAIN_R,
      background: 'var(--bg-node-main)',
      border: `2px solid var(--border-node)`,
      boxShadow: 'var(--shadow-node-main)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      userSelect: 'none',
      transition: 'box-shadow 0.4s ease, transform 0.2s ease',
      animation: 'glowPulse 4s ease-in-out infinite',
      zIndex: 10,
    }),
    mainLabel: {
      fontFamily: 'var(--font-serif)',
      fontSize: '0.92rem',
      fontWeight: 600,
      color: 'var(--gold-light)',
      textAlign: 'center',
      lineHeight: 1.3,
      letterSpacing: '0.02em',
      whiteSpace: 'pre-line',
      padding: '0 12px',
    },
    mainSub: {
      fontSize: '0.48rem',
      color: 'rgba(212,175,90,0.45)',
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      marginTop: '4px',
      textAlign: 'center',
      padding: '0 10px',
    },
    svg: {
      position: 'absolute',
      left: '-600px', top: '-600px',
      width: '1200px', height: '1200px',
      pointerEvents: 'none',
      overflow: 'visible',
      zIndex: 1,
    },
    controlBar: {
      position: 'absolute',
      bottom: '20px',
      left: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '4px',
      zIndex: 50,
    },
    ctrl: (active) => ({
      width: '38px', height: '38px',
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--border)',
      background: active ? 'var(--gold)' : 'var(--bg-alt)',
      color: active ? 'var(--bg-header)' : 'var(--text-secondary)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer',
      transition: 'var(--transition)',
      backdropFilter: 'blur(8px)',
      boxShadow: '0 2px 8px var(--shadow)',
    }),
  }), [transform, panMode]);

  return (
    <div
      ref={containerRef}
      style={{
        ...s.container,
        backgroundImage: `radial-gradient(circle, var(--canvas-dot) 1px, transparent 1px)`,
        backgroundSize: '28px 28px',
      }}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* World (transformed) */}
      <div style={s.world}>
        {/* SVG connecting lines */}
        <svg style={s.svg} aria-hidden="true">
          <defs>
            <filter id="lineGlow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>
          {expanded && childPositions.map((pos, i) => (
            <path
              key={i}
              d={curvePath(600, 600, 600 + pos.x, 600 + pos.y)}
              stroke="var(--line-color)"
              strokeWidth="1.5"
              fill="none"
              filter="url(#lineGlow)"
              strokeDasharray="600"
              style={{
                animation: `lineIn 0.6s ease ${i * 0.1 + 0.1}s both`,
              }}
            />
          ))}
        </svg>

        {/* Child nodes */}
        {expanded && tabData.children.map((child, i) => {
          const pos = childPositions[i] || { x: 0, y: 0 };
          const isActive = activeChild === child.id;
          return (
            <div
              key={child.id}
              onClick={(e) => handleChildClick(e, child)}
              style={{
                position: 'absolute',
                width:  CHILD_R * 2,
                height: CHILD_R * 2,
                borderRadius: '50%',
                left: pos.x - CHILD_R,
                top:  pos.y - CHILD_R,
                background: isActive ? 'var(--gold)' : 'var(--bg-node)',
                border: `1.5px solid ${isActive ? 'var(--gold-light)' : 'var(--border-node)'}`,
                boxShadow: isActive
                  ? '0 0 0 3px var(--gold-dim), 0 4px 24px var(--gold-glow)'
                  : 'var(--shadow-node)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                userSelect: 'none',
                zIndex: 5,
                animation: `nodeIn 0.55s cubic-bezier(0.34,1.56,0.64,1) ${i * 0.09 + 0.05}s both`,
                transition: 'box-shadow 0.3s ease, background 0.3s ease, border-color 0.3s ease',
              }}
            >
              <span style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '0.72rem',
                fontWeight: 600,
                color: isActive ? 'var(--bg-header)' : 'var(--text)',
                textAlign: 'center',
                lineHeight: 1.3,
                whiteSpace: 'pre-line',
                letterSpacing: '0.01em',
                padding: '0 10px',
              }}>
                {child.label}
              </span>
            </div>
          );
        })}

        {/* Main node */}
        <div style={s.mainNode(expanded)} onClick={handleMainClick}>
          {/* Decorative ring */}
          <div style={{
            position: 'absolute', inset: '-8px',
            borderRadius: '50%',
            border: '1px solid var(--gold-dim)',
            pointerEvents: 'none',
          }} />
          <div style={{
            position: 'absolute', inset: '-16px',
            borderRadius: '50%',
            border: '1px solid rgba(184,137,42,0.08)',
            pointerEvents: 'none',
          }} />
          <span style={{ fontSize: '1.1rem', marginBottom: '4px', opacity: 0.7, color: 'var(--gold)' }}>
            {tabData.main.symbol}
          </span>
          <span style={s.mainLabel}>{tabData.main.label}</span>
          <span style={s.mainSub}>
            {expanded ? 'tap a node to read' : 'click to explore'}
          </span>
        </div>
      </div>

      {/* Floating Controls */}
      <div style={s.controlBar}>
        <button style={s.ctrl(panMode)} onClick={() => setPanMode(p => !p)} title="Pan mode" aria-label="Toggle pan mode">
          <PanIcon />
        </button>
        <button style={s.ctrl(false)} onClick={() => zoomBy(1.2)} title="Zoom in" aria-label="Zoom in">
          <ZoomInIcon />
        </button>
        <button style={s.ctrl(false)} onClick={() => zoomBy(0.83)} title="Zoom out" aria-label="Zoom out">
          <ZoomOutIcon />
        </button>
        <button style={s.ctrl(false)} onClick={resetView} title="Reset view" aria-label="Reset view">
          <ResetIcon />
        </button>
      </div>
    </div>
  );
}
