import React from 'react';
import LanguageSelector from './LanguageSelector.jsx';
import { LANGUAGES } from '../data/content.js';

const SunIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <circle cx="12" cy="12" r="5" />
    <line x1="12" y1="1" x2="12" y2="3" /><line x1="12" y1="21" x2="12" y2="23" />
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" /><line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
    <line x1="1" y1="12" x2="3" y2="12" /><line x1="21" y1="12" x2="23" y2="12" />
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" /><line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
  </svg>
);

const MoonIcon = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
  </svg>
);

const GlobeIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <circle cx="12" cy="12" r="10" />
    <line x1="2" y1="12" x2="22" y2="12" />
    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
  </svg>
);

export default function Header({ activeTab, onTabChange, darkMode, onToggleDark, language, onLanguageChange, langTrayOpen, onToggleLangTray }) {
  const currentLang = LANGUAGES.find(l => l.code === language) || LANGUAGES[1];

  const s = {
    wrapper: {
      background: 'var(--bg-header)',
      borderBottom: '1px solid rgba(184,137,42,0.2)',
      boxShadow: '0 2px 20px rgba(0,0,0,0.4)',
      position: 'relative',
      zIndex: 100,
      flexShrink: 0,
    },
    inner: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
      height: '64px',
      gap: '16px',
    },
    brand: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1,
      minWidth: 0,
      flexShrink: 0,
    },
    title: {
      fontFamily: 'var(--font-serif)',
      fontSize: '1.25rem',
      fontWeight: 700,
      color: 'var(--gold-light)',
      letterSpacing: '0.02em',
      whiteSpace: 'nowrap',
    },
    tagline: {
      fontSize: '0.6rem',
      color: 'rgba(212,175,90,0.55)',
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      marginTop: '2px',
    },
    tabs: {
      display: 'flex',
      gap: '8px',
      alignItems: 'center',
    },
    tab: (active) => ({
      fontFamily: 'var(--font-serif)',
      fontSize: '1.05rem',
      fontWeight: active ? 600 : 400,
      color: active ? 'var(--bg-header)' : 'rgba(212,175,90,0.7)',
      background: active ? 'var(--gold-light)' : 'transparent',
      border: '1.5px solid',
      borderColor: active ? 'var(--gold-light)' : 'rgba(212,175,90,0.35)',
      borderRadius: 'var(--radius-full)',
      padding: '7px 22px',
      cursor: 'pointer',
      transition: 'var(--transition)',
      whiteSpace: 'nowrap',
      letterSpacing: '0.01em',
    }),
    right: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      flexShrink: 0,
    },
    langBtn: {
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      background: 'rgba(212,175,90,0.08)',
      border: '1px solid rgba(212,175,90,0.3)',
      borderRadius: 'var(--radius-full)',
      padding: '6px 14px',
      color: 'rgba(212,175,90,0.9)',
      cursor: 'pointer',
      fontSize: '0.78rem',
      fontFamily: 'var(--font-sans)',
      transition: 'var(--transition)',
    },
    darkBtn: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: '34px',
      height: '34px',
      background: 'rgba(212,175,90,0.08)',
      border: '1px solid rgba(212,175,90,0.3)',
      borderRadius: 'var(--radius-full)',
      color: 'rgba(212,175,90,0.9)',
      cursor: 'pointer',
      transition: 'var(--transition)',
      flexShrink: 0,
    },
  };

  return (
    <div style={s.wrapper}>
      <div style={s.inner}>
        {/* Brand */}
        <div style={s.brand}>
          <span style={s.title}>✦ Eucharist & Mary</span>
          <span style={s.tagline}>St. Carlo Acutis, Pray For Us!</span>
        </div>

        {/* Tab Switcher */}
        <div style={s.tabs}>
          <button style={s.tab(activeTab === 'eucharist')} onClick={() => onTabChange('eucharist')}>
            The Eucharist
          </button>
          <button style={s.tab(activeTab === 'mary')} onClick={() => onTabChange('mary')}>
            Mary
          </button>
        </div>

        {/* Right Controls */}
        <div style={s.right}>
          <button style={s.langBtn} onClick={onToggleLangTray} aria-label="Language selector">
            <GlobeIcon />
            <span>{currentLang.label}</span>
            <span style={{ opacity: 0.5, fontSize: '0.65rem', marginLeft: '2px' }}>{langTrayOpen ? '▲' : '▼'}</span>
          </button>
          <button style={s.darkBtn} onClick={onToggleDark} aria-label="Toggle dark mode">
            {darkMode ? <SunIcon /> : <MoonIcon />}
          </button>
        </div>
      </div>

      {/* Language Tray */}
      <LanguageSelector
        open={langTrayOpen}
        language={language}
        onSelect={(code) => { onLanguageChange(code); onToggleLangTray(); }}
      />
    </div>
  );
}
