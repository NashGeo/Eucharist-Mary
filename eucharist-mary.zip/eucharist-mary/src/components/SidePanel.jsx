import React, { useEffect, useRef } from 'react';

const CloseIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
);

const ImagePlaceholder = ({ label }) => (
  <div style={{
    width: '100%',
    height: '160px',
    background: 'var(--bg-alt)',
    border: '1px dashed var(--border)',
    borderRadius: 'var(--radius-md)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '6px',
    marginBottom: '24px',
  }}>
    <span style={{ fontSize: '1.5rem', opacity: 0.25 }}>✦</span>
    <span style={{ fontSize: '0.68rem', color: 'var(--text-light)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
      Image placeholder — {label}
    </span>
  </div>
);

export default function SidePanel({ open, node, onClose }) {
  const scrollRef = useRef(null);

  // Reset scroll on new node
  useEffect(() => {
    if (open && scrollRef.current) scrollRef.current.scrollTop = 0;
  }, [node, open]);

  // Close on Escape
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape' && open) onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onClose]);

  const s = {
    overlay: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(0,0,0,0)',
      zIndex: open ? 40 : -1,
      pointerEvents: open ? 'auto' : 'none',
      transition: 'background 0.3s ease',
    },
    panel: {
      position: 'absolute',
      top: 0,
      right: 0,
      bottom: 0,
      width: 'min(var(--panel-width), 100vw)',
      background: 'var(--bg-panel)',
      borderLeft: '1px solid var(--border-panel)',
      boxShadow: open ? '-8px 0 40px rgba(0,0,0,0.18)' : 'none',
      display: 'flex',
      flexDirection: 'column',
      transform: open ? 'translateX(0)' : 'translateX(100%)',
      transition: 'transform 0.38s cubic-bezier(0.4,0,0.2,1)',
      zIndex: 50,
      animation: open && node ? 'fadeIn 0.38s ease both' : 'none',
    },
    panelHead: {
      padding: '22px 22px 16px',
      borderBottom: '1px solid var(--border)',
      flexShrink: 0,
    },
    closeBtn: {
      position: 'absolute',
      top: '16px',
      right: '18px',
      width: '32px', height: '32px',
      borderRadius: 'var(--radius-full)',
      border: '1px solid var(--border)',
      background: 'transparent',
      color: 'var(--text-secondary)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer',
      transition: 'var(--transition)',
    },
    title: {
      fontFamily: 'var(--font-serif)',
      fontSize: '1.6rem',
      fontWeight: 700,
      color: 'var(--text)',
      lineHeight: 1.2,
      marginBottom: '6px',
      paddingRight: '36px',
      whiteSpace: 'pre-line',
    },
    subtitle: {
      fontSize: '0.75rem',
      color: 'var(--text-light)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
    },
    scriptureNote: {
      margin: '14px 0 0',
      padding: '8px 14px',
      background: 'var(--gold-dim)',
      borderLeft: '3px solid var(--gold)',
      borderRadius: '0 var(--radius-sm) var(--radius-sm) 0',
      fontSize: '0.7rem',
      color: 'var(--text-secondary)',
      fontStyle: 'italic',
      lineHeight: 1.5,
    },
    scrollArea: {
      flex: 1,
      overflowY: 'auto',
      padding: '22px',
    },
    section: {
      marginBottom: '24px',
      paddingBottom: '24px',
      borderBottom: '1px solid var(--border)',
    },
    sectionTitle: {
      fontFamily: 'var(--font-serif)',
      fontSize: '1.1rem',
      fontWeight: 600,
      color: 'var(--text)',
      marginBottom: '10px',
    },
    sectionBody: {
      fontSize: '0.85rem',
      lineHeight: 1.75,
      color: 'var(--text-panel)',
      whiteSpace: 'pre-line',
    },
    footer: {
      flexShrink: 0,
      padding: '14px 22px',
      borderTop: '1px solid var(--border)',
      textAlign: 'center',
    },
    footerText: {
      fontFamily: 'var(--font-serif)',
      fontSize: '0.68rem',
      color: 'var(--text-light)',
      letterSpacing: '0.08em',
      fontStyle: 'italic',
    },
  };

  return (
    <>
      {/* Backdrop (non-blocking — just dim, don't block canvas) */}
      <div
        style={{ ...s.overlay, background: open ? 'rgba(0,0,0,0.15)' : 'rgba(0,0,0,0)' }}
        onClick={onClose}
      />

      {/* Panel */}
      <div style={s.panel} role="dialog" aria-modal="true" aria-label={node?.label || 'Node detail'}>
        {node && (
          <>
            {/* Header */}
            <div style={s.panelHead}>
              <button style={s.closeBtn} onClick={onClose} aria-label="Close panel">
                <CloseIcon />
              </button>
              <h2 style={s.title}>{node.label}</h2>
              <p style={s.subtitle}>{node.subtitle}</p>
              {node.isScripture && (
                <p style={s.scriptureNote}>
                  All Scripture quotations are from the Revised Standard Version, Second Catholic Edition (RSV-2CE).
                </p>
              )}
            </div>

            {/* Scrollable content */}
            <div style={s.scrollArea} ref={scrollRef}>
              {/* Image placeholder */}
              <ImagePlaceholder label={node.label} />

              {/* Content sections */}
              {Array.isArray(node.content) && node.content.map((section, i) => (
                <div
                  key={i}
                  style={{
                    ...s.section,
                    ...(i === node.content.length - 1 ? { borderBottom: 'none', marginBottom: 0, paddingBottom: 0 } : {}),
                    animationDelay: `${i * 0.06}s`,
                  }}
                >
                  <h3 style={s.sectionTitle}>{section.heading}</h3>
                  <p style={s.sectionBody}>{section.body}</p>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div style={s.footer}>
              <p style={s.footerText}>
                Ad Majorem Dei Gloriam · St. Carlo Acutis, pray for us.
              </p>
            </div>
          </>
        )}
      </div>
    </>
  );
}
